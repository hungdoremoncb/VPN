<?php
namespace Home\Controller;
use Think\Controller;

class FenController extends BaseController{

    public function addpage(){
        if (C('agent_pay') == '1') {
            $user = session('user');
            if ($user['t_id']) {
                $agentinfo = M('user')->where("id = {$user['t_id']}")->find();
                if ($agentinfo['t_id']) {
                    $agentinfo = M('user')->where("id = {$agentinfo['t_id']}")->find();
                    if ($agentinfo['t_id']) {
                        $agentinfo = M('user')->where("id = {$agentinfo['t_id']}")->find();
                    }
                }
                $pay = $agentinfo;
            } else {
                $info = M('config')->where("id = 2")->find();
                $pay['wx_paycode'] = $info['kefu'];
                $info1 = M('config')->where("id = 3")->find();
                $pay['zfb_paycode'] = $info1['kefu'];
            }
        } else {
            $info = M('config')->where("id = 2")->find();
            $pay['wx_paycode'] = $info['kefu'];
            $info1 = M('config')->where("id = 3")->find();
            $pay['zfb_paycode'] = $info1['kefu'];
        }
        $this->assign('pay',$pay);
        $this->display();
    }

    public function xiapage(){
        $uid = session('user')?session('user')['id']:'';
        $info = array();
        $info = M('user')->field('id,bank,bank_name,bank_user,tk_password')->where('id='.$uid)->find();
        if($info['bank']){
            $this->assign('info',$info);
            $this->display();
        }else{
            $this->display('user/tkInfo1');
        }
    }

    protected function send($content){
        // 指明给谁推送，为空表示向所有在线用户推送
        $to_uid = "";
        // 推送的url地址，上线时改成自己的服务器地址
        $push_api_url = "http://localhost:2128/";
        $post_data = array(
            "type" => "publish",
            "content" => json_encode($content),
            "to" => $to_uid,
        );
        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $push_api_url );
        curl_setopt ( $ch, CURLOPT_POST, 1 );
        curl_setopt ( $ch, CURLOPT_HEADER, 0 );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $post_data );
        curl_setopt ($ch, CURLOPT_HTTPHEADER, array("Expect:"));
        $return = curl_exec ( $ch );
        curl_close ( $ch );
        return $return;
    }

    public function add(){
        $id = I('id');
		//echo $id;exit;
        $money = I('money');
        $userinfo = M('user')->where("id={$id}")->find();
        $add = array(
            'uid' => $id,
            't_id' => $userinfo['t_id'],
            'money' => $money,
            'balance' => $userinfo['points'],
            'nickname' => $userinfo['nickname'],
            'headimgurl' => $userinfo['headimgurl'],
            'addtime' => time()
        );
        $res = M('fenadd')->add($add);
        if ($res) {
            $message  = array(
                'time'=>date('H:i:s'),
                'type' => 1,
                'content'=>"上分申请"
            );
            $res = $this->send($message);
          echo json_encode(['status'=>1,'info'=>'申请成功,等待审核，跳转中','url'=>'']);exit;
        } else {
              echo json_encode(['status'=>0,'info'=>'申请失败,请联系客服','url'=>'']);exit;
        }
    }

    /**
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * money:1
    type:1
    bank_account:1
    back_address:11
    back_name:1
    password:123456s
    uid:13
    Name

     */
    public function xia(){
        $data = I('request.');
        $userinfo = M('user')->where("id={$data['uid']}")->find();
        if($userinfo['bank']==''){
            echo json_encode(['status'=>0,'info'=>'您还没设置提款信息,请到个人中心去设置','url'=>'']);exit;
            //$this->error('您还没设置提款信息,请到个人中心去设置',U('home/user/index'),0);
        }
        //if(md5($data['password'])!=$userinfo['tk_password']){
        //	echo json_encode(['status'=>0,'info'=>'您输入的提款密码错误,请重新输入','url'=>'']);exit;
        //$this->error('您输入的提款密码错误,请重新输入');
        //}
        // $win_rate = C('win_rate') ;
        // $fenadd = M('integral')->field('sum(points) as p,sum(send_balance) as sb,sum(hidden_balance) as hb')->where(['uid'=>$data['uid']])->find();
        // $fenadd2 = M('fenadd')->field("sum(money) as sm,sum(send_balance) as sb")->where(['uid'=>$data['uid']])->find();
        // $all_in = $fenadd2['sm'];
        //var_dump($all_in);

        // $all_flow = $fenadd['p'] + $fenadd['sb'] + $fenadd['hb'] - abs($userinfo['edit_integral']);
        //var_dump($all_flow);
        //if( $all_flow / $all_in  <= ($win_rate+1) ){
         //   echo json_encode(['status'=>0,'data'=>[],'info'=>"收益率未达到:".$win_rate * 100 ."%,不能提现"]);exit;
        //}
        // $sum_order = M('Order')->field('sum(del_points) as p')->where(['userid'=>$userinfo['id']])->find();
        // $fenxia = M('fenxia')->field('sum(money) as m')->where(['uid'=>$userinfo['id']])->find();
        // $amount = $all_in * $win_rate;
        // $can_draw = $sum_order['p'];
        // //$can_draw = $can_draw > $userinfo['points'] ? $userinfo['points'] : $can_draw > 0 ? $can_draw :0;
        // if($userinfo['code_number']!=0){
        // if($can_draw<$userinfo['code_number']){
        //     echo json_encode(['status'=>0,'data'=>[],'info'=>"打码量未达到不能提现"]);exit;
        // }}
        $fenxia = M('fenxia')->field('count(*) c')->where(['uid'=>$userinfo['id'], 'status'=>0])->find();
        if ( $fenxia && $fenxia['c']>0 ) {
            echo json_encode(['status'=>0,'info'=>'请等待上个请求处理完成后再提款', 'url'=>'']);exit;
        } // End If

        if($data['money'] > $userinfo['points']){
            echo json_encode(['status'=>0,'info'=>'可提现额度不够','url'=>'']);exit;
        }

        $data['balance'] = $userinfo['points'];
        $data['t_id'] = $userinfo['t_id'];
        $data['nickname'] = $userinfo['nickname'];
        $data['headimgurl'] = $userinfo['headimgurl'];
        $data['addtime'] = time();
        // if ( $data['money'] % 100 != 0) {
        //     $data['money'] -= $data['money'] % 100 ;
        // } // End If
        unset($data['password']);
        $res = M('fenxia')->add($data);
        if ($res) {
            $message  = array(
                'time'=>date('H:i:s'),
                'type' => 2,
                'content'=>"下分申请"
            );
            $res = $this->send($message);
            echo json_encode(['status'=>1,'info'=>'申请成功,等待审核，跳转中','url'=>'']);exit;
            //$this->success('申请成功,等待审核，跳转中~',U('Home/Run/index'),1);
        } else {

            echo json_encode(['status'=>0,'info'=>'申请失败,请联系客服','url'=>'']);exit;
            //$this->error('申请失败，请联系客服');
        }
    }
}
?>

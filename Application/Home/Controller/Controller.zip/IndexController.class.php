<?php

namespace Home\Controller;

use Think\Controller;

header('content-type:text/html;charset=utf-8');

class IndexController extends BaseController
{


    public function index()
    {
        if (C('is_open') == 0) {
            $this->redirect('error');
        }

        $t_id = I('t');
        session('tid', $t_id);
        if (IS_POST){
            $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ?"https://": "http://";

            $url = $protocol . $_SERVER['HTTP_HOST'] ;
            $banner_list = M('banner')->order('sort desc')->select();
            foreach ($banner_list as &$val ){
                $val['thumb'] = $url.'/Uploads/'.$val['thumb'];
            }
            echo json_encode(['status'=>1,'info'=>'','data'=>C('welcome'),'list'=>$banner_list]);exit;
        }
        if (C('is_baidu')) {
            $this->display("baidu");
        } else {
            $siteurl = $_SERVER['HTTP_HOST'];
            if (C('is_weixin') == '1' && is_weixin()) {
                $oauth = load_wechat('Oauth');
                if (C('mp_choose') == '1') {
                    $host_url = 'http://' . $siteurl . '/Home/Index/redirect_url';
                    //$redirect_uri = 'http://'.C('mp_host_url').'/Home/Index/auth_cb?host_url='.urlencode($host_url);
                    $redirect_uri = 'http://m.gszl9.cn/' . '/Home/Index/redirect_url';
                } else {
                    //$redirect_uri =  'http://'.$siteurl.'/Home/Index/redirect_url';
                    $redirect_uri = 'http://m.gszl9.cn/m/' . '/Home/Index/redirect_url';
                }

                $result_index = $oauth->getOauthRedirect($redirect_uri, $state, 'snsapi_userinfo');
                header("location:" . $result_index);
            } else {
                $result_index = 'http://' . $siteurl . '/Home/Run/index';
                header("location:" . $result_index);
            }
        }
    }

    public function lists(){
        $list = [];
        $list = M('activity')->where([])->order('sort desc')->select();
        $count = 0;
        echo json_encode(['status'=>1,'list'=>$list,'ccount'=>$count,'info'=>'']);exit;
    }

    // //百度一下搜索
    // public function baidu()
    // {
    //     $value = I('baidu_value');
    //     if (C('baidu_value') != $value) {
    //         $url = 'https://www.baidu.com/s?wd=' . $value;
    //         header("location:" . $url);
    //         exit;
    //     } else {
    //         $siteurl = $_SERVER['HTTP_HOST'];
    //         if (C('is_weixin') == '1' && is_weixin()) {
    //             $oauth = load_wechat('Oauth');
    //             if (C('mp_choose') == '1') {
    //                 $host_url = 'http://' . $siteurl . '/Home/Index/redirect_url';
    //                 //$redirect_uri = 'http://'.C('mp_host_url').'/Home/Index/auth_cb?host_url='.urlencode($host_url);
    //                 $redirect_uri = 'http://m.gszl9.cn' . '/Home/Index/redirect_url';
    //             } else {
    //                 //$redirect_uri =  'http://'.$siteurl.'/Home/Index/redirect_url';
    //                 $redirect_uri = 'http://m.gszl9.cn' . '/Home/Index/redirect_url';
    //             }
    //             $result_index = $oauth->getOauthRedirect($redirect_uri, $state, 'snsapi_userinfo');
    //             header("location:" . $result_index);
    //         } else {
    //             $result_index = 'http://' . $siteurl . '/Home/Run/index';
    //             header("location:" . $result_index);
    //         }
    //     }
    // }

    //登录
    public function login()
    {
        if (IS_POST) {
            //            if (!IS_AJAX) {
            ////                $this->success('提交方式不正确！');
            //            } else {
            $username = I('username');
            $password = md5(I('password'));
            $map = array();
            $map['username'] = $username;
            $map['password'] = $password;
            $res = M('user')->where($map)->find();
            if ($res) {
                // $map['last_ip'] = get_client_ip();
                // $map['last_time'] = time();
                // M('user')->where("id = {$res['id']}")->save($map);

                //是否禁用
                //if ($res['status'] == 0) {
                //   echo json_encode(['status'=>401,'info'=>'该账户已冻结！请联系客服']);exit;
                //                        $this->redirect('error');
                //}
                session('user', $res);
                $userlog = array(
                    'username' => $res['username'],
                    'nickname' => $res['nickname'],
                    'type' => 5, //1 下注  2中奖 3上分  4下分  5登录系统
                    'addtime' => time(),
                    'content' => "用户[" . $res['nickname'] . "]登录系统，登录时间" . date('Y-m-d H:i:s', time()),
                );
                M('userlog')->add($userlog);
                $login=array(
                    'user_login' => 1,
                    'user_agent' => json_encode(get__browser(), true),
                    'last_ip' => get_client_ip(),
                    'last_time' => time()
                );
                M('user')->where('id='.$res['id'])->save($login);

                //更新推广二维码
                // $siteurl = $_SERVER['HTTP_HOST'];
                // $url = 'http://'.$siteurl.'?t='.$res['id'];
                // $img = qrcode($url);
                // M('user')->where("id = {$res['id']}")->setField('qrcode','/'.$img);
                unset($res['user_agent']);
                echo json_encode(['info'=>'登录成功,跳转中~','url'=> U('/Home/Run/index'),'data'=>$res,'status'=>1]);exit;
                // $this->success('登录成功,跳转中~', U('/Home/Run/index'), 1);
            } else {
                echo json_encode(['info'=>'用户名或密码错误','url'=> '','status'=>0]);exit;
                $this->error('用户名或密码错误');
            }
            //            }
        } else {
            $this->display();
        }
    }

    public function checklogin(){
        $userid = session('user');
        if($userid){
            $res = M('user')->where("id = {$userid['id']}")->find();
            if ($res['status'] == 0) {
                session(null);
                echo json_encode(['status'=>401,'info'=>'该账户已冻结！请联系客服']);
            }else{
                echo json_encode(['status'=>200,'info'=>'']);
            }
            exit;
        }
    }

    //注册

    //注册
    public function register()
    {
        if (C('is_open_reg') == 0) {
            $this->redirect('error');
        }
        if (IS_POST) {
            //            if (!IS_AJAX) {
            //                $this->error('提交方式不正确！');
            //            } else {
            $username = trim(I('username'));
            $password = md5(I('password'));
            $res = M('user')->where("username = '{$username}'")->find();

            if (!$res) {
                $reg_data = array(
                    'nickname' => $username,
                    'username' => $username,
                    'password' => $password,
                    'headimgurl' => I('headimgurl'),
                    'reg_time' => time(),
                    'reg_ip' => get_client_ip(),
                    'user_login'=>1
                );
                //是否推荐
                $t_id = session('tid');
                if ($t_id) {
                    $reg_data['t_id'] = $t_id;
                }

                $reg_id = M('user')->add($reg_data);

                if ($reg_id) {
                    //更新推广二维码
                    // $auth_url = "http://" . $auth['site_url']."/Home/Index/authcheck?auth_code=9STWmr4ENbk0dQalLpRIN12N93tf5KMQ";
                    // $auth = curlGet($auth_url);
                    // $auth = trim($auth, chr(239) . chr(187) . chr(191));
                    // $auth = json_decode($auth, true);
                    /* if (!$auth) {
                       $this->error();
                       } */
                    // $id = I('id');
                    // $url = "http://" . $auth['site_url'] . "/Home/get/go?auth_code=" . C('auth_code') . "&t_id=" . $reg_id;

                    // $siteurl = $_SERVER['HTTP_HOST'];
                    // $url = 'http://'.$siteurl.'?t='.$reg_id;

                    // $img = qrcode($url);
                    // M('user')->where("id = $reg_id")->setField('qrcode', '/' . $img);

                    $user = M('user')->where("id={$reg_id}")->find();
                    session('user', $user);

                    $login=array();
                    $login['user_login']=1;

                    M('user')->where('id='.$user['id'])->save($login);
                    echo json_encode(['info'=>'注册成功,跳转中~','url'=>U('/Home/User/tkppwd'),'status'=>1]);exit;
                    $this->success('注册成功,跳转中~', U('/Home/User/tkppwd'), 1);
                } else {

                    echo json_encode(['info'=>'注册失败','url'=>U('/Home/User/tkppwd'),'status'=>0]);exit;
                    $this->error('注册失败，请重试');
                }

            } else {
                echo json_encode(['info'=>'用户名已存在，请重新输入','url'=>U('/Home/User/tkppwd'),'status'=>0]);exit;
                $this->error('用户名已存在，请重新输入');
            }
            //            }
        } else {
            $this->display();
        }

    }

    //退出
    public function logout()
    {
        $user=session('user');
        $login=array();
        $login['user_login']=0;
        $res=M('user')->where('id='.$user['id'])->save($login);
        if($res){
            session(null);
            $this->redirect('/Home/Run/index');
        }
    }

    public function redirect_url()
    {
        $oauth = load_wechat('Oauth');
        $result = session('result');
        if (!$result) {
            $result = $oauth->getOauthAccessToken();
            session('result', $result);
        }

        // $result['openid'] = "ospyFwRJLb2tMQeb5HxCzRsmAoks";
        //判断是否第一次登陆
        $wx = M('wx');
        $user = M('user');
        $res = $wx->where("openid = '{$result['openid']}'")->find();
        if ($res) {
            //是否过期
            if ($res['expires_in'] < time()) {
                $wx->where("openid = '{$result['openid']}'")->setField('access_token', $result['access_token']);
            }
            //查找会员数据
            $info = $user->where("id = {$res['userid']}")->find();

            $userlog = array(
                'username' => $info['username'],
                'nickname' => $info['nickname'],
                'type' => 5, //1 下注  2中奖 3上分  4下分  5登录系统
                'addtime' => time(),
                'content' => "用户[" . $info['nickname'] . "]登录系统，登录时间" . date('Y-m-d H:i:s', time()),
            );
            M('userlog')->add($userlog);

            //是否禁用
            if ($info['status'] == 0) {
                $this->redirect('error');
            }

            //更新推广二维码

            // $siteurl = $_SERVER['HTTP_HOST'];
            // $url = 'http://'.$siteurl.'?t='.$info['id'];
            // $img = qrcode($url);
            // $user->where("id = {$res['userid']}")->setField('qrcode','/'.$img);

            // $info['qrcode'] = '/'.$img;
            session('user', $info);

            $this->redirect('Home/Run/index');
        } else {
            if (C('is_open_reg') == 0) {
                $this->redirect('error');
            }
            $userinfo = session('userinfo');
            if (!$userinfo) {
                $userinfo = $oauth->getOauthUserinfo($result['access_token'], $result['openid']);
                session('userinfo', $userinfo);
            }

            //是否推荐
            $t_id = session('tid');
            if ($t_id) {
                $data['t_id'] = $t_id;
            }
            //自动注册
            $data['nickname'] = $userinfo['nickname'];
            $headimgurl = substr($userinfo['headimgurl'], 0, -2);
            $data['headimgurl'] = $userinfo['headimgurl'];
            $data['country'] = $userinfo['country'];
            $data['province'] = $userinfo['province'];
            $data['sex'] = $userinfo['sex'];
            $data['user_agent'] = serialize(get__browser());
            $data['city'] = $userinfo['city'];
            $data['reg_ip'] = get_client_ip();
            $data['last_ip'] = get_client_ip();
            $data['reg_time'] = time();
            $data['last_time'] = time();
            $data['logins'] = 1;

            //绑定用户名
            $username = mt_rand(100000, 999999);
            $user_find = M('user')->where("username={$username}")->find();
            if ($user_find) {
                $username = mt_rand(100000, 999999);
            }
            $data['username'] = $username;
            $data['password'] = md5('123456');

            $userid = $user->add($data);
            if ($userid) {
                //推荐码（二维码 ）
                /*
                  $auth_url = "http://auth.httx06.cn/Home/Index/authcheck?auth_code=9STWmr4ENbk0dQalLpRIN12N93tf5KMQ";
                  $auth = curlGet($auth_url);
                  $auth = trim($auth, chr(239) . chr(187) . chr(191));
                  $auth = json_decode($auth, true);
                  if (!$auth) {
                  $this->error();
                  }*/

                $id = I('id');
                $url = "http://" . $auth['site_url'] . "/Home/get/go?auth_code=" . C('auth_code') . "&t_id=" . $userid;

                // $siteurl = $_SERVER['HTTP_HOST'];
                // $url = 'http://'.$siteurl.'?t='.$userid;
                $img = qrcode($url);
                $user->where("id = $userid")->setField('qrcode', '/' . $img);

                $data1['userid'] = $userid;
                $data1['openid'] = $result['openid'];
                $data1['access_token'] = $result['access_token'];
                $data1['expires_in'] = time() + $result['expires_in'];
                $res2 = $wx->add($data1);
                if ($res2) {
                    $data['id'] = $userid;
                    $data['qrcode'] = '/' . $img;
                    session('user', $data);
                    $this->redirect('Home/Run/index');
                }
            }
        }
    }

    //房间说明
    public function shuoming_show()
    {
        if (IS_GET) {
            $name = I('game');
            $where = array(
                'game' => $name
            );
            $info = M('gametest')->where($where)->find();
            echo '<html>
                        <head>
                            <title></title>
                        </head>
                        <body>
                            <div class="regulation">
                                <h3 class="cl-red" txt-al-c="">' . $info['title'] . '</h3>
                                ' . $info['test'] . '
                            </div>


                        </body>
                  </html>';
        }
    }

    public function bind()
    {
        $id = I('id');
        $user = M('user')->where("id={$id}")->find();
        if (!$user['username']) {
            $username = mt_rand(100000, 999999);
            $user_find = M('user')->where("username={$username}")->find();
            if ($user_find) {
                $username = mt_rand(100000, 999999);
            }
            $user['username'] = $username;
        }

        $this->assign("user", $user);
        $this->display();

    }

    public function bind_action()
    {
        $data = I('request.');
        $data['password'] = md5(I('password'));
        $res = M('user')->where("id={$data['id']}")->save($data);
        if ($res) {
            $this->success("绑定成功");
        } else {
            $this->error("绑定失败");
        }
    }

    public function bj28()
    {
        if(I('userid')){
            $userid = I('userid');
            $userinfo = M('user')->where('id='.$userid)->find();
            $fenxia_process = M('fenxia')->field('sum(money) as m')->where(['uid'=>$userinfo['id'], 'status'=>0])->find();
            $userinfo['points'] = $userinfo['points']-$fenxia_process['m'];
            $userinfo['points'] = $userinfo['points']>0?$userinfo['points']:0;
            $userinfo['points'] = floor($userinfo['points']*100)/100;
            $userinfo['code_number']=$userinfo['points'];
            $list = [
                ['count'=>20000,'name' => '北京28普通房','usermin_point'=>C('bj28_1_usermin_point'),'url'=> '/Home/Run/bj28_1','min_point'=>C('bj28_1qi_min_point')],
                ['count'=>13000,'name' => '北京28中级房','usermin_point'=>C('bj28_2_usermin_point'),'url'=> '/Home/Run/bj28_2','min_point'=>C('bj28_2qi_min_point')],
                ['count'=>8200,'name' => '北京28高级房','usermin_point'=>C('bj28_3_usermin_point'),'url'=> '/Home/Run/bj28_3','min_point'=>C('bj28_3qi_min_point')],
            ];
            echo json_encode(['status'=>1,'data'=>['list'=>$list,'userinfo'=>$userinfo] ,'info'=>'成功']);exit;
        }
        $this->display();
    }

    public function jnd28()
    {
        $auth = auth_check(C('auth_code'),$_SERVER['HTTP_HOST']);
        if (!$auth) {
            echo "未授权或授权已过期";exit;
        }

        $userid = session('user');

        $userinfo = M('user')->where("id = {$userid['id']}")->find();
        $fenxia_process = M('fenxia')->field('sum(money) as m')->where(['uid'=>$userinfo['id'], 'status'=>0])->find();
        $userinfo['points'] = $userinfo['points']-$fenxia_process['m'];
        $userinfo['points'] = $userinfo['points']>0?$userinfo['points']:0;
        $userinfo['points'] = floor($userinfo['points']*100)/100;
        $userinfo['code_number']=$userinfo['points'];
        //下线总数
        $userinfo['t_account'] = M('user')->where("t_id = {$userid['id']}")->count() ? : 0;

        //今日盈亏
        $map = array();
        $beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
        $endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;

        $map['time'] = array(array('egt',$beginToday),array('elt',$endToday),'and');
        $map['state'] = 1;
        $map['userid'] = $userid['id'];

        $yinkui = M('order')->field("sum(add_points) as sum_add,sum(del_points) as sum_del")->where($map)->find();
        $userinfo['ying'] = $yinkui['sum_add'] - $yinkui['sum_del'];

        //今日推广佣金
        $map_y['time'] = array(array('egt',$beginToday),array('elt',$endToday),'and');
        $map_y['t_uid'] =  $userid['id'];
        $yong = M('push_money')->where($map_y)->field("sum(money) as money")->find();

        $is_weixin = is_weixin();
        $userinfo['yong_today'] = $yong['money'] ? : 0;
        $kefu = M('config')->where("id = 1")->find();
        if(I('userid')){
            $list = [
                ['count'=>19000,'name'=>'新手仓','usermin_point'=>C('jnd28_1_usermin_point'),'min_point'=>C('jnd28_1qi_min_point'),'url'=>"/Home/Run/jnd28_1"],
                ['count'=>11000,'name'=>'普通VIP仓','usermin_point'=>C('jnd28_2_usermin_point'),'min_point'=>C('jnd28_2qi_min_point'),'url'=>"/Home/Run/jnd28_2"],
                ['count'=>8000,'name'=>'白银VIP仓','usermin_point'=>C('jnd28_3_usermin_point'),'min_point'=>C('jnd28_3qi_min_point'),'url'=>"/Home/Run/jnd28_3"]
            ];
            echo json_encode(['status'=>1,'data'=>['kefu'=>$kefu,'is_weixin'=>$is_weixin,'list'=>$list,'user'=>$userinfo] ,'info'=>'成功']);exit;
        }
        $this->assign('kefu',$kefu);

        $this->assign('is_weixin',$is_weixin);

        $this->assign("user",$userinfo);

        $this->display();
    }


    public function wanfa(){
        $article_id = I('article_id');
		$uri = $_SERVER['REQUEST_URI'];

        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ?"https://": "http://";

        $url = $protocol . $_SERVER['HTTP_HOST'] ;
        $content_re = htmlspecialchars(str_replace('src="/', 'src="'.$url."/",htmlspecialchars_decode(C('product_text'))));
        echo json_encode(['status'=>1,'info'=>'获取成功','data'=>$content_re]);

    }
    public function act_list(){

        $uri = $_SERVER['REQUEST_URI'];

        $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ?"https://": "http://";

        $url = $protocol . $_SERVER['HTTP_HOST'] ;
        $count =  M('activity')->field("count(id) as count")->where([])->find();
        $page = new \Think\Page($count['count'],50);
        $list = M('activity')->where([])->limit($page->firstRow.','.$page->listRows)->select();
        foreach($list as &$val){
            $val['content'] = htmlspecialchars(str_replace('src="/', 'src="'.$url."/",htmlspecialchars_decode($val['content'])));
            $val['addtime'] = date("Y-m-d ",$val['addtime']);
            $val['thumb'] = $url.'/Uploads/'.$val['thumb'];
        }
        echo  json_encode(['status'=>1,'data'=>['list'=>$list,'count'=>$count]]);
    }

    public function getSysTime(){
        die(json_encode(['sysTime2'=>date('Y-m-d H:i:s'), 'sysTime1'=>date('YmdHis')])) ;
    }
}

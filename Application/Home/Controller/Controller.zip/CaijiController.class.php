<?php

namespace Home\Controller;
use Think\Server;

header('content-type:text/html;charset=utf-8');
class CaijiController extends Server {

    protected $socket = 'websocket://0.0.0.0:7777';
    public $apihost = "http://127.0.0.1/";

    protected function getFdata( $type_key, $period ){
        $today=strtotime(date("Y-m-d",time()));
        $dayno=ceil((time()-$today)/$period);
        $num=rand(0,9).",".rand(0,9).",".rand(0,9);
        $offset=-740000;
        $prefix=1;
        if ( $type_key=='bj28' ) {
            $offset=0;
            $prefix=8;
        } // End If
        $expect=$dayno+288*($today-strtotime('2019-07-16'))/3600/24+541588+$offset;
        $opentime=date("Y-m-d H:i:s",$today+$dayno*$period-$period);
        $rs = array(
            'data'=>array(array(
                'gameid'=>'5fc',
                'opentime'=>$opentime,
                'opencode'=>$num,
                'expect'=>$prefix.$expect,
            )),
            'msg'=>''
        );
        // return json_encode($rs);
        return $rs;
    }

    protected function caiji_5fc28( $type_key='bj28', $period=180 ){
        $time = time();
        // $type_key='bj28';
        // $period = 3 * 60;
        $fdata = $this->getFdata($type_key, $period);
        $fdata = $fdata['data'][0];
        //$cr_data = json_decode($cpk,true);

        //foreach ($fdata  as  $v) {
        $periodnumber = $fdata['expect'];
        $awardtime = date('Y-m-d H:i:s', strtotime($fdata['opentime']));
        $awardnumbers = $fdata['opencode'];
        $caijinum = M('caiji')->where("game = '$type_key'")->limit(0,1)->order("id desc")->find();
        $data = array(
            'periodnumber' => $periodnumber,
            'awardnumbers' => $awardnumbers,
            'awardtime' => $awardtime,
            'game' => $type_key,
            'addtime' => time()
        );
        // ���ݱ����ʱ, ֱ��д��ǰ�Ľ�ȥ
        if ( $caijinum==null ) {
            echo "init ${type_key}\n";
            $res = M('caiji')->add($data);
            return $res;
        }
        if (time() - strtotime($caijinum['awardtime']) <= $period) {
            return false;
        }
        $kongzhi = M('kongzhi')->where("periodnumber = '$periodnumber' and game='$type_key'")->limit(0,1)->order("id desc")->find();
        if ($kongzhi) {
            //���ƿ���
            $data['awardnumbers'] = $kongzhi['awardnumbers'];
        }

        if(strval($caijinum['periodnumber']) != $periodnumber  && $periodnumber > $caijinum['periodnumber']) {
            M('caiji')->add($data);
        }
    }

    /*���Ӷ�ʱ��
     *�������״̬
     * */
    public function onWorkerStart(){

        //PC��������28�ɼ�
        if (C('bj28_kj_select') == 1) {
            \Workerman\Lib\Timer::add(5, function(){
                $this->caiji_5fc28('bj28', 3*60);
            });
        }

        //PC��������28�ɼ�
        if (C('jnd28_kj_select') == 1) {
            //xyft�����ɼ�
            \Workerman\Lib\Timer::add(5, function(){
                $this->caiji_5fc28('jnd28', 3*60);
            });
        }

        \Workerman\Lib\Timer::add(60, function(){
            // var_dump('ssssssssssssssss');
            //�����Զ���ˮ
            if (C('is_auto_fs') == '1') {
                if (time() == strtotime('06:00:01')) {
                    // $this->update_config(array('is_open'=>0));
                    if (C('who_fs') == '1') {
                        //�Զ���ˮ
                        $agents = M('user')->where("status = 1 and is_agent = 1")->select();

                        foreach ($agents as $a => $b) {
                            $time = date('Y-m-d',mktime(0,0,0,date('m'),date('d')-1,date('Y')));

                            $aid = $b['id'];
                            //��ѯ�����Ƿ��ѷ�ˮ
                            $is_fs = M('fs_date')->where("fs_date='{$time}' and a_id = {$aid}")->find();
                            if ($is_fs) {
                                continue;
                            }

                            //��ѯ�������еĶ���,���˷���
                            $start_time = strtotime($time.' 00:00:00');
                            $end_time = $start_time + 24*3600;

                            $map['time'] = array(array('egt',$start_time),array('elt',$end_time),'and');
                            $map['state'] = 1;
                            $map['t_id'] = $aid;
                            $order = M("order");
                            $list = $order->field("userid,nickname,SUM(add_points) AS add_points,SUM(del_points) AS del_points")->where($map)->group('userid')->select();
                            $fs_date = array(
                                'fs_date' => $time,
                                'add_time' => time()
                            );
                            $fs_date['water'] = 0;
                            $fs_water['pkft'] = 0;
                            $fs_water['ssc'] = 0;
                            $fs_water['k3'] = 0;
                            $fs_water['pcdd'] = 0;

                            $t_userinfo = M('user')->field('pkft_fs,ssc_fs,pcdd_fs,k3_fs,yong')->where("id = {$aid}")->find();
                            foreach ($list as $key => $value) {
                                $fs_date['water'] += $value['del_points'];
                                if ($value['game'] == 'pk10' || $value['game'] == 'xyft') {
                                    $fs_water['pkft'] += $value['del_points'] * $t_userinfo['pkft_fs'] *0.01;
                                } else if($value['game'] == 'ssc') {
                                    $fs_water['ssc'] += $value['del_points'] * $t_userinfo['ssc_fs'] *0.01;
                                } else if($value['game'] == 'k3') {
                                    $fs_water['k3'] += $value['del_points'] * $t_userinfo['k3_fs'] *0.01;
                                }
                                else {
                                    $fs_water['pcdd'] += $value['del_points'] * $t_userinfo['pcdd_fs'] *0.01;
                                }
                            }

                            $fs_date['fs_money'] = $fs_water['pkft'] + $fs_water['ssc'] + $fs_water['k3'] + $fs_water['pcdd'] ;

                            $fs_date['a_id'] = $aid;

                            //�Ƿ������ˮ���Ӵ�����Ӷ���п�
                            $yong_res = M('user')->where("id = {$aid}")->setDec("yong",$fs_date['fs_money']);
                            $zero_res = M('user')->where("id = {$aid}")->save(array('yong'=>0));
                            $fs_res = M('fs_date')->add($fs_date);

                            foreach ($list as $key => $value) {
                                $list[$key]['fs_id'] = $fs_res;
                                $list[$key]['date'] = $time;
                                $list[$key]['water'] = $value['del_points'];

                                if ($value['game'] == 'pk10' || $value['game'] == 'xyft') {
                                    $list[$key]['money'] = $value['del_points']  * $t_userinfo['pkft_fs'] *0.01;
                                }
                                else if($value['game'] == 'ssc') {
                                    $list[$key]['money'] = $value['del_points']  * $t_userinfo['ssc_fs'] *0.01;
                                }
                                else if($value['game'] == 'k3') {
                                    $list[$key]['money'] = $value['del_points']  * $t_userinfo['k3_fs'] *0.01;
                                }
                                else {
                                    $list[$key]['money'] = $value['del_points']  * $t_userinfo['pcdd_fs'] *0.01;
                                }
                                //����Ա���²���
                                $res = M('user')->where("id={$value['userid']}")->setInc('fanshui', $list[$key]['money']);
                            }

                            $fs_detail_res = M('fs_details')->addAll($list);

                        }
                    } else {
                        $time = date('Y-m-d',mktime(0,0,0,date('m'),date('d')-1,date('Y')));

                        //��ѯ�����Ƿ��ѷ�ˮ
                        $is_fs = M('fs_date')->where("fs_date='{$time}'")->find();
                        if ($is_fs) {
                            return;
                        }

                        //��ѯ�������еĶ���,���˷���
                        $start_time = strtotime($time.' 00:00:00');
                        $end_time = $start_time + 24*3600;

                        $map['time'] = array(array('egt',$start_time),array('elt',$end_time),'and');
                        $map['state'] = 1;

                        if (C('is_dxds_fs') == '0') {
                            $map['type'] = array('neq','1');
                        }

                        $order = M("order");
                        $list = $order->field("userid as uid,nickname,SUM(add_points) AS add_points,SUM(del_points) AS del_points,game")->where($map)->group('userid')->select();

                        $fs_date = array(
                            'fs_date' => $time,
                            'add_time' => time()
                        );
                        $fs_date['water'] = 0;
                        $fs_water['bj28_1'] = 0;
                        $fs_water['bj28_2'] = 0;
                        $fs_water['bj28_3'] = 0;
                        $fs_water['jnd28_1'] = 0;
                        $fs_water['jnd28_2'] = 0;
                        $fs_water['jnd28_3'] = 0;

                        foreach ($list as $key => $value) {
                            $fs_date['water'] += $value['del_points'];
                            if ($value['game'] == 'bj28_1') {
                                $fs_water['bj28_1'] += $value['del_points'] * C('bj28_1_fs_rate') *0.01;
                                $fs_water['bj28_1'] += $value['del_points'] * C('bj28_1_fs_rate') *0.01;
                            } else if($value['game'] == 'bj28_2') {
                                $fs_water['bj28_2'] += $value['del_points'] * C('bj28_2_fs_rate') *0.01;
                            } else if($value['game'] == 'bj28_3') {
                                $fs_water['bj28_3'] += $value['del_points'] * C('bj28_3_fs_rate') *0.01;
                            } else if($value['game'] == 'jnd28_1') {
                                $fs_water['jnd28_1'] += $value['del_points'] * C('jnd28_1_fs_rate') *0.01;
                            } else if($value['game'] == 'jnd28_2') {
                                $fs_water['jnd28_2'] += $value['del_points'] * C('jnd28_2_fs_rate') *0.01;
                            } else if($value['game'] == 'jnd28_3') {
                                $fs_water['jnd28_3'] += $value['del_points'] * C('jnd28_3_fs_rate') *0.01;
                            }
                        }

                        $fs_date['fs_money'] = $fs_water['bj28_1'] + $fs_water['bj28_2'] + $fs_water['bj28_3'] + $fs_water['jnd28_1'] + $fs_water['jnd28_2'] + $fs_water['jnd28_3'] ;


                        $fs_res = M('fs_date')->add($fs_date);

                        foreach ($list as $key => $value) {
                            $list[$key]['fs_id'] = $fs_res;
                            $list[$key]['date'] = $time;
                            $list[$key]['water'] = $value['del_points'];

                            if ($value['game'] == 'bj28_1') {
                                $list[$key]['money'] = $value['del_points'] * C('bj28_1_fs_rate') *0.01;
                            } else if($value['game'] == 'bj28_2') {
                                $list[$key]['money'] = $value['del_points'] * C('bj28_2_fs_rate') *0.01;
                            } else if($value['game'] == 'bj28_3') {
                                $list[$key]['money'] = $value['del_points'] * C('bj28_3_fs_rate') *0.01;
                            } else if($value['game'] == 'jnd28_1') {
                                $list[$key]['money'] =  $value['del_points'] * C('jnd28_1_fs_rate') *0.01;
                            } else if($value['game'] == 'jnd28_2') {
                                $list[$key]['money'] =  $value['del_points'] * C('jnd28_2_fs_rate') *0.01;
                            } else if($value['game'] == 'jnd28_3') {
                                $list[$key]['money'] =  $value['del_points'] * C('jnd28_3_fs_rate') *0.01;
                            }

                            //����Ա���²���
                            $res = M('user')->where("id={$value['uid']}")->setInc('fanshui', $list[$key]['money']);
                        }

                        $fs_detail_res = M('fs_details')->addAll($list);
                    }
                }
            }

            if (time() == strtotime('08:00:00')) {
                // $this->update_config(array('is_open'=>1));
            }
        });
    }

    /*
     * �ͻ�������ʱ
     *
     * */
    public function onConnect($connection){
        $connection->onWebSocketConnect = function($connection , $http_header)
        {

        };
    }

    /**
     * onMessage
     * @access public
     * ת���ͻ�����Ϣ
     * @param  void
     * @param  void
     * @return void
     */
    public function onMessage($connection, $data) {

    }

    /**
     * onClose
     * �ر�����
     * @access public
     * @param  void
     * @return void
     */
    public function onClose($connection) {

    }

    public function update_config($post) {
        $filename = 'site.php';
        $config_file = CONF_PATH . $filename;
        if (is_file($config_file) && is_writable($config_file)) {

            $config =
                require $config_file;

            $config = array_merge($config, $post);

            file_put_contents($config_file, "<?php \nreturn " . stripslashes(var_export($config, true)) . ";", LOCK_EX);

            @unlink(RUNTIME_FILE);

            return true;

        } else {

            return false;

        }

    }
}
?>

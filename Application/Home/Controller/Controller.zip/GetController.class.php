<?php

namespace Home\Controller;
use Think\Controller;

header('content-type:text/html;charset=utf-8');
class GetController extends Controller{

	public function getPk10(){
		$caiji = M('caiji')->where("game='pk10'")->limit(0,1)->order("id desc")->find();
		$format = json_decode(pk10_format($caiji),true);
		// if (strtotime($format['current']['awardTime']) > strtotime("23:56:00")) {
		// 	$time = strtotime($format['next']['awardTime']) + 9*60*60-300;
		// 	$format['next']['awardTime'] = date('Y-m-d H:i:s',$time);
		// }
		echo json_encode($format);
	}
	
	public function getXyft(){
		$caiji = M('caiji')->where("game='xyft'")->limit(0,1)->order("id desc")->find();
		$format = json_decode(xyft_format($caiji),true);
		echo json_encode($format);
	}
	
	public function text () {
		$url = 'http://182.61.40.81:810/json/index?ticketname=xy28';
		$josn2 = http_get($url);
		echo $josn2;
		$fdata = json_decode($josn2,true);
		
		$fdataOne = $fdata['0'];
		
		var_dump($fdataOne);
		
	}

	public function getSsc(){
		$number = M('number')->where("game='ssc'")->limit(0,1)->order("id desc")->find();

		$time = time();
		if ($time > strtotime("02:00:00") && $time < strtotime("21:57:00")) {
			$n_awardTime = strtotime($number["awardtime"]) + 590;
		} else {
			$n_awardTime = strtotime($number["awardtime"]) + 290;
		}

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawTime" =>  $number['awardtime'],
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		    "dragonTiger" =>   $number['lh'],
		    "sumSingleDouble" =>   $number['tema_ds'],
		    "status" =>  0,
		    "id" =>  "#numBig",
		    'counttime' =>  abs($n_awardTime - time()),
		);
		
		echo json_encode($json_data);
	}

//	public function getBj28_1(){
//		$number = M('number')->where("game='bj28'")->limit(0,1)->order("id desc")->find();
//		$n_awardTime = strtotime($number["awardtime"]) + 300;
//
//		$json_data =  array(
//		    "preDrawCode" => explode(',',$number['awardnumbers']),
//		    "drawIssue"=>$number['periodnumber']+1,
//		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
//		    "preDrawIssue" =>  $number['periodnumber'],
//		    "sumNum" =>  $number['tema'],
//		    "sumBigSmall" =>  $number['tema_dx'],
//		     "sumSingleDouble" =>   $number['tema_ds'],
//		    "time" => abs($n_awardTime - time()),
//		);
//		echo json_encode($json_data);
//	}



    public function getBj28(){
        $number = M('number')->where("game='bj28'")->limit(0,1)->order("id desc")->find();
        $n_awardTime = strtotime($number["awardtime"]) + 336;

        $json_data =  array(
            "preDrawCode" => explode(',',$number['awardnumbers']),
            "drawIssue"=>$number['periodnumber']+1,
            "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
            "preDrawIssue" =>  $number['periodnumber'],
            "sumNum" =>  $number['tema'],
            "sumBigSmall" =>  $number['tema_dx'],
          //  "time" => abs($n_awardTime - time()),
            "time"=>strval($n_awardTime-C('bj28_stop_time')-time()),
        );
        echo json_encode($json_data);
    }


//	public function getBj28(){
//		$number = M('number')->where("game='bj28'")->limit(0,1)->order("id desc")->find();
//		$n_awardTime = strtotime($number["awardtime"]) + 280;
//		    echo "
//{
//		\"time\":" .$this->getTimestamp(13) . ",
//		\"current\": {
//			\"game\":\"" . 'xy28' . "\",
//			\"periodNumber\":\"" . $number['periodnumber'] . "\",
//			\"awardTime\":\"" . $number["awardtime"]. "\",
//			\"awardNumbers\":\"" .$number['awardnumbers']. "\"
//		},
//		\"next\":{
//			\"game\":\"" . 'xy28' . "\",
//			\"periodNumber\":\"" . ($number['periodnumber']+1). "\",
//			\"awardTime\":\"" . date('Y-m-d H:i:s',$n_awardTime) . "\",
//			\"fengTime\":\"" . strval($n_awardTime-C('bj28_stop_time') - time()) . "\",
//			\"awardTimeInterval\":" . strval($n_awardTime - time()) . ",
//			\"delayTimeInterval\": 0
//		}
//	}
//
//";exit;
//	}



    public function getJnd28(){
        $number = M('number')->where("game='jnd28'")->limit(0,1)->order("id desc")->find();
        $n_awardTime = strtotime($number["awardtime"]) + 230;
        $json_data =  array(
            "preDrawCode" => explode(',',$number['awardnumbers']),
            "drawIssue"=>$number['periodnumber']+1,
            "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
            "preDrawIssue" =>  $number['periodnumber'],
            "sumNum" =>  $number['tema'],
            "sumBigSmall" =>  $number['tema_dx'],
            "time" => strval($n_awardTime-C('jnd28_stop_time') - time()),
        );
        echo json_encode($json_data);
    }



//		public function getJnd28(){
//		$number = M('number')->where("game='jnd28'")->limit(0,1)->order("id desc")->find();
//		$n_awardTime = strtotime($number["awardtime"]) + 200;
//		    echo "
//{
//		\"time\":" .$this->getTimestamp(13) . ",
//		\"current\": {
//			\"game\":\"" . 'xy28' . "\",
//			\"periodNumber\":\"" . $number['periodnumber'] . "\",
//			\"awardTime\":\"" . $number["awardtime"]. "\",
//			\"awardNumbers\":\"" .$number['awardnumbers']. "\"
//		},
//		\"next\":{
//			\"game\":\"" . 'xy28' . "\",
//			\"periodNumber\":\"" . ($number['periodnumber']+1). "\",
//			\"awardTime\":\"" . date('Y-m-d H:i:s',$n_awardTime) . "\",
//			\"fengTime\":\"" . strval($n_awardTime-C('jnd28_stop_time') - time()) . "\",
//			\"awardTimeInterval\":" . strval($n_awardTime - time()) . ",
//			\"delayTimeInterval\": 0
//		}
//	}
//
//";exit;
//	}

	function getTimestamp($digits = false)
	{
	    $digits = $digits > 10 ? $digits : 10;
	    $digits = $digits - 10;
	    if ((!$digits) || ($digits == 10)) {
	        return time();
	    } else {
	        return number_format(microtime(true), $digits, '', '');
	    }
	}



	public function getK3(){
		$number = M('number')->where("game='k3'")->limit(0,1)->order("id desc")->find();
		$n_awardTime = strtotime($number["awardtime"]) + 480;

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawIssue"=>$number['periodnumber']+1,
		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		     "sumSingleDouble" =>   $number['tema_ds'],
		    "time" => abs($n_awardTime - time()),
		);
		echo json_encode($json_data);
	}

	public function getK3bj(){
		$number = M('number')->where("game='k3bj'")->limit(0,1)->order("id desc")->find();
		$n_awardTime = strtotime($number["awardtime"]) + 500;

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawIssue"=>$number['periodnumber']+1,
		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		     "sumSingleDouble" =>   $number['tema_ds'],
		    "time" => abs($n_awardTime - time()),
		);
		echo json_encode($json_data);
	}

	public function getK3gx(){
		$number = M('number')->where("game='k3gx'")->limit(0,1)->order("id desc")->find();
		$n_awardTime = strtotime($number["awardtime"]) + 500;

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawIssue"=>$number['periodnumber']+1,
		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		     "sumSingleDouble" =>   $number['tema_ds'],
		    "time" => abs($n_awardTime - time()),
		);
		echo json_encode($json_data);
	}
	
	public function getK3jl(){
		$number = M('number')->where("game='k3jl'")->limit(0,1)->order("id desc")->find();
		$n_awardTime = strtotime($number["awardtime"]) + 500;

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawIssue"=>$number['periodnumber']+1,
		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		     "sumSingleDouble" =>   $number['tema_ds'],
		    "time" => abs($n_awardTime - time()- C('k3_stop_time')),
		);
		echo json_encode($json_data);
	}

	public function getK3ah(){
		$number = M('number')->where("game='k3ah'")->limit(0,1)->order("id desc")->find();
		$n_awardTime = strtotime($number["awardtime"]) + 500;

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawIssue"=>$number['periodnumber']+1,
		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		     "sumSingleDouble" =>   $number['tema_ds'],
		    "time" => abs($n_awardTime - time()-C('sto')),
		);
		echo json_encode($json_data);
	}

	public function getK3fj(){
		$number = M('number')->where("game='k3fj'")->limit(0,1)->order("id desc")->find();
		$n_awardTime = strtotime($number["awardtime"]) + 500;

		$json_data =  array(
		    "preDrawCode" => explode(',',$number['awardnumbers']),
		    "drawIssue"=>$number['periodnumber']+1,
		    "drawTime" =>  date('Y-m-d H:i:s',$n_awardTime),
		    "preDrawIssue" =>  $number['periodnumber'],
		    "sumNum" =>  $number['tema'],
		    "sumBigSmall" =>  $number['tema_dx'],
		     "sumSingleDouble" =>   $number['tema_ds'],
		    "time" => abs($n_awardTime - time()),
		);
		echo json_encode($json_data);
	}
}

?>
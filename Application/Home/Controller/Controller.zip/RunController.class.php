<?php

namespace Home\Controller;

use Think\Controller;

class RunController extends BaseController
{

    public function ssc_kj()
    {
        $this->display();
    }

    public function bj28_kj()
    {
        $this->display();
    }


    public function bj28_fn()
    {
        $game = I('game');
        $this->assign('game', $game);
        $this->display();
    }

    public function jnd28_kj()
    {
        $this->display();
    }

    public function kefu_wx()
    {
        $info = M('config')->where("id =1")->find();
        $this->assign('info', $info);
        $this->display();
    }

    public function index()
    {

        //        $var = 'wangya';
        //
        //        if(! $var ) $var = time().'b891037e3d772605f56f8e9877d8593c';
        //        $varstr = strlen( $var );
        //        if( $varstr < 1 ) $varstr = 32;
        //        $hash = md5( ('#@$^%&^*&(#'.md5( base64_encode( $var.'.@#!$#@%#soft.com'.md5($var).'WangYa'. $var.'][{)(*&^%#@!~1d').'@monsof ~!~$^%&^*&(t'. $varstr). $varstr));
        //
        //        echo substr( $hash ,1 , $varstr * 3 );
        //
        //
        //        exit;
        if (C('is_open') == 0) {
            $this->redirect('error');
        }
        $kefu = M('config')->where("id = 1")->find();
        $is_weixin = is_weixin();

        $auth = auth_check(C('auth_code'), $_SERVER['HTTP_HOST']);
        if (!$auth) {
            echo "未授权或授权已过期";
            exit;
        }


        $adminconf = M('admin_config')->where('id=2')->field('peoplenumber,moneynumber')->find();
        //互动列表
        $article = M('hd');
        $count = $article->count();
        $page = new \Think\Page($count, 5);
        $show = $page->show();
        $list = $article->limit($page->firstRow . ',' . $page->listRows)->order("addtime desc")->select();
        $wheredata = array(
            'game' => "首页说明设置",
            'status' => 1
        );
        $neirong = M('gametest')->where($wheredata)->find();
        $this->assign('neirong', $neirong);

        $this->assign('data', $adminconf);

        $this->assign('show', $show);
        $this->assign('list', $list);
        $this->assign("auth", $auth);
        $this->assign('is_weixin', $is_weixin);
        $this->assign('kefu', $kefu);
        if (C('index_page') == '2') {
            $this->display("index_2");
        } else if (C('index_page') == '1') {
            $this->display("index_1");
        } else {
            $this->display('index_3');
        }

    }


    public function bj28()
    {
        if (C('is_open') == 0) {
            $this->redirect('error');
        }

        //10期结果
        $list = M('number')->where("game='bj28'")->order("id DESC")->limit(40)->select();

        // // 创建SDK实例
        // $script = &load_wechat('Script');
        // // 获取JsApi使用签名，通常这里只需要传 $ur l参数
        // $url = 'http://' . $_SERVER['SERVER_NAME'] . '/Home/Run/index.html';
        // $options = $script->getJsSign($url, $timestamp, $noncestr, $appid);
        $options=NULL;

        //判断赛车和飞艇的类型
        $kefu = M('config')->where("id = 1")->find();

        $is_weixin = is_weixin();

        $this->assign('is_weixin', $is_weixin);
        $this->assign('kefu', $kefu);

        $this->assign('list', $list);
        $this->assign('type', $type);
        $this->assign('options', $options);
        $this->display();
    }


    public function bj28_1()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }

    public function bj28_2()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }

    public function bj28_3()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }

    public function jnd28_1()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }

    public function jnd28_2()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }

    public function jnd28_3()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }

    public function jnd28_4()
    {
        $lotto_type=ACTION_NAME;
        $this->getLottoInfo($lotto_type);
    }


    /*竞猜*/
    public function jincaibj28_1()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='bj28_1'")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }

    /*竞猜*/
    public function jincaibj28_2()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='bj28_2'")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }

    /*竞猜*/
    public function jincaibj28_3()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='bj28_3'")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }

    /*竞猜*/
    public function jincaijnd28_1()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='jnd28_1' and status = 0")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }

    /*竞猜*/
    public function jincaijnd28_2()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='jnd28_2'")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }

    /*竞猜*/
    public function jincaijnd28_3()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='jnd28_3'")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }

    /*竞猜*/
    public function jincaijnd28_4()
    {
        //聊天信息
        $list = M('message')->where("status=1 and game='jnd28_4'")->order("id DESC")->limit(40)->select();
        $this->assign('list', $list);
        $this->display();
    }


    //开奖记录
    public function kjbj28()
    {
        //20期结果
        $list = M('number')->where("game='bj28'")->order("id DESC")->limit(40)->select();

        foreach ($list as $key => $value) {
            $current_number = $value;
            $number1 = explode(',', $current_number['awardnumbers']);
            $tema_number = $number1[0] + $number1[1] + $number1[2];
            if ($tema_number <= 13) {
                if ($tema_number % 2 == 0) {
                    $current_number['zuhe'] = '小双';
                } else {
                    $current_number['zuhe'] = '小单';
                }
            } else {
                if ($tema_number % 2 == 0) {
                    $current_number['zuhe'] = '大双';
                } else {
                    $current_number['zuhe'] = '大单';
                }
            }

            if ($tema_number == 0) {
                $current_number['jdx'] = '极小';
            } else if ($tema_number ==  27) {
                $current_number['jdx'] = '极大';
            } else {
                $current_number['jdx'] = '';
            }
            $list[$key] = $current_number;
        }

        $this->assign('list', $list);
        $this->display();
    }

    //开奖记录
    public function kjjnd28()
    {
        //20期结果
        $list = M('number')->where("game='jnd28'")->order("id DESC")->limit(40)->select();

        foreach ($list as $key => $value) {
            $current_number = $value;
            $number1 = explode(',', $current_number['awardnumbers']);
            $tema_number = $number1[0] + $number1[1] + $number1[2];
            if ($tema_number <= 13) {
                if ($tema_number % 2 == 0) {
                    $current_number['zuhe'] = '小双';
                } else {
                    $current_number['zuhe'] = '小单';
                }
            } else {
                if ($tema_number % 2 == 0) {
                    $current_number['zuhe'] = '大双';
                } else {
                    $current_number['zuhe'] = '大单';
                }
            }

            if ($tema_number == 0) {
                $current_number['jdx'] = '极小';
            } else if ($tema_number ==  27) {
                $current_number['jdx'] = '极大';
            } else {
                $current_number['jdx'] = '';
            }
            $list[$key] = $current_number;
        }

        $this->assign('list', $list);
        $this->display();
    }


    /*客服*/
    public function kefu()
    {
        $kefu = M('config')->where("id = 1")->find();
        $this->assign('kefu', $kefu);
        $this->display();
    }

    //推广二维码
    public function tui()
    {
        $uid = I('uid');
        $userinfo = M('user')->where("id={$uid}")->find();

        $this->assign('tui', $userinfo['qrcode']);
        $siteurl = $_SERVER['SERVER_NAME'];
        $url = 'http://' . $siteurl . '?t=' . $uid;
        $this->assign('url', $url);
        $this->display();
    }

    public function app()
    {
        $this->display();
    }

    /*记录*/
    public function record()
    {
        $t = I('t');

        $map = array();
        if ($t == 1) {
            if (time() <= strtotime("06:00:00")) {
                $beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
                $endToday = mktime(0, 0, 0, date('m'), date('d') + 1, date('Y')) - 1;
            } else {
                $beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
                $endToday = mktime(0, 0, 0, date('m'), date('d') + 1, date('Y')) - 1;
            }
        }
        if ($t == 2) {
            $beginToday = mktime(0, 0, 0, date('m'), date('d') - 1, date('Y'));
            $endToday = mktime(0, 0, 0, date('m'), date('d'), date('Y')) - 1;
        }
        if ($t == 3) {
            $beginToday = mktime(0, 0, 0, date('m'), date('d') - 2, date('Y'));
            $endToday = mktime(0, 0, 0, date('m'), date('d') - 1, date('Y')) - 1;
        }
        if ($t == 4) {
            $beginToday = 0;
            $endToday = 0;
        }
        if ($beginToday and $endToday) {
            $map['time'] = array(array('egt', $beginToday), array('elt', $endToday), 'and');
        }
        $userinfo = session('user');
        $map['state'] = 1;
        $map['userid'] = $userinfo['id'];

        $order = M('order');
        $count = $order->where($map)->count();
        $points_tj = $order->field("count(id) as count,sum(add_points) as sum_add,sum(del_points) as sum_del")->where($map)->find();
        $points_tj['ying'] = $points_tj['sum_add'] - $points_tj['sum_del'];
        $page = new \Think\Page($points_tj['count'], 6);
        $show = $page->show();
        $list = $order->field("*")->where($map)->limit($page->firstRow . ',' . $page->listRows)->order("id DESC")->select();

        $number = array();
        for ($i = 0; $i < count($list); $i++) {
            if (!in_array($list[$i]['number'], $number)) {
                $number[] = $list[$i]['number'];
            }
            for ($a = 0; $a < count($number); $a++) {
                if ($list[$i]['number'] == $number[$a]) {
                    $list1[$a]['number'] = $number[$a];
                    $list1[$a]['game'] = $list[$i]['game'];
                    $list1[$a]['order'][] = $list[$i];
                }
            }
        }


        $bj28_1data = F('bj28_1data');
        $bj28_2data = F('bj28_2data');
        $bj28_3data = F('bj28_3data');
        $jnd28_1data = F('jnd28_1data');
        $jnd28_2data = F('jnd28_2data');
        $jnd28_3data = F('jnd28_3data');
        $jnd28_4data = F('jnd28_4data');


        $this->assign('list1', $list1);
        $this->assign('state', F('state'));

        $this->assign('bj28_1number', $bj28_1data['next']['periodNumber']);
        $this->assign('bj28_2number', $bj28_2data['next']['periodNumber']);
        $this->assign('bj28_3number', $bj28_3data['next']['periodNumber']);
        $this->assign('jnd28_1number', $jnd28_1data['next']['periodNumber']);
        $this->assign('jnd28_2number', $jnd28_2data['next']['periodNumber']);
        $this->assign('jnd28_3number', $jnd28_3data['next']['periodNumber']);
        $this->assign('jnd28_4number', $jnd28_4data['next']['periodNumber']);

        $this->assign('list', $list);
        $this->assign('points_tj', $points_tj);
        $this->assign('show', $show);
        $this->assign('today', mktime(0, 0, 0, date('m'), date('d'), date('Y')));
        $this->assign('t', $t);
        $this->display();
    }

    /*规则*/
    public function rulebj28_1()
    {
        $config = M('config')->where("id=4")->find();
        $this->assign("config", $config);
        $this->display();
    }

    /*规则*/
    public function rulebj28_2()
    {
        $config = M('config')->where("id=5")->find();
        $this->assign("config", $config);
        $this->display();
    }

    /*规则*/
    public function rulebj28_3()
    {
        $config = M('config')->where("id=6")->find();
        $this->assign("config", $config);
        $this->display();
    }


    /*规则*/
    public function rulejnd28_1()
    {
        $config = M('config')->where("id=7")->find();
        $this->assign("config", $config);
        $this->display();
    }

    /*规则*/
    public function rulejnd28_2()
    {
        $config = M('config')->where("id=8")->find();
        $this->assign("config", $config);
        $this->display();
    }

    /*规则*/
    public function rulejnd28_3()
    {
        $config = M('config')->where("id=9")->find();
        $this->assign("config", $config);
        $this->display();
    }

    /*规则*/
    public function rulejnd28_4()
    {
        $config = M('config')->where("id=9")->find();
        $this->assign("config", $config);
        $this->display();
    }

    /*查询分数*/
    public function check_points()
    {
        if (IS_POST) {
            if (IS_AJAX) {
                $id = I('id');
                if ($id) {
                    $userinfo = M('user')->where("id = $id")->find();
                    if ($userinfo) {
                        $userinfo['error'] = 0;
                    }
                }
                $this->ajaxReturn($userinfo);
            }
        }
    }

    public function del()
    {
        $id = I('id');
        $info = M('order')->where("id = $id")->find();
        if (!$info) {
            $data['error'] == 0;
            $data['msg'] == '未找到订单';
        } else {
            $state = F($info['game'] . '_state');
            $pkdata = F($info['game'] . 'data');
            if ($state == 1) {
                $id = I('id');
                if ($info['number'] == $pkdata['next']['periodNumber']) {
                    $res = M('order')->where("id = $id")->setField('state', 0);
                    if ($res) {
                        $data['error'] == 1;
                        //加分
                        M('user')->where("id = {$info['userid']}")->setInc('points', $info['del_points']);
                        //记录日志
                        $userlog = array(
                            'username' => $info['username'],
                            'nickname' => $info['nickname'],
                            'type' => 6, //1 下注  2中奖 3上分  4下分  5登录系统   6取消下注
                            'addtime' => time(),
                            'content' => "用户取消订单，期号[" . $info['number'] . "],取消金额[" . $info['del_points'] . "],取消下注内容[" . $info['jincai'] . "]",
                        );
                        M('userlog')->add($userlog);
                    } else {
                        $data['error'] == 0;
                        $data['msg'] == '删除失败';
                    }
                } else {
                    $data['error'] == 0;
                    $data['msg'] == '本期已封盘';
                }
            } else {
                $data['error'] == 0;
                $data['msg'] == '本期已封盘';
            }
        }
        $this->ajaxReturn($data);


    }

    public function hd()
    {
        $id = I('id');
        $info = M('hd')->where("id = {$id}")->find();
        $this->assign("info", $info);
        $this->display();
    }


    public function kaijiang()
    {
        $type = I('type');
        //20期结果
        $list = M('number')->where("game='{$type}'")->order("id DESC")->limit(40)->select();

        $this->assign("list", $list);
        $this->display();
    }

    /***
     * 跟单
     */
    public function create_order()
    {
        $userid = I('post.userid');
        // var_dump($userid);exit;
        $type = I('post.game_type');
        $jnd28_1_state = F($type . '_state');
        $json_data = json_decode(htmlspecialchars_decode(I('post.json_data')),true);
        //var_dump($json_data);exit;
        $jifen = M('user')->where("id = $userid")->find();
        $amount = 0;
        foreach ($json_data as $message_data) {
            $res = check_format_bj28($message_data['content'], C($type . 'qi_min_point'), C($type . 'qi_max_point'), C($type . '_xz_open'), C($type . '_xz_max'));
            $res['type'] = 1;
            if ($res['type'] && isset($res['amount']) ) {
                $amount += $res['amount'];
            }
            if($res['error'] == 0 || $res['error'] == 2){

            }elseif($res['type']){

            }else{
                echo json_encode(['status'=>0,'info'=>'格式不正确']);exit;
            }
        }

        if ($jifen['points'] < $amount) {
            $points_error = array(
                'uid' => $userid,
                'type' => 'say',
                'head_img_url' => $message_data['headimgurl'],
                'from_client_name' => $message_data['client_name'],
                'content' => $message_data['content'],
                'time' => date('H:i:s')
            );
            $points_error['type'] = 'say_error';
            $points_tips = array(
                'uid' => $userid,
                'type' => 'admin',
                'head_img_url' => '/Public/main/img/kefu.jpg',
                'from_client_name' => 'GM管理员111',
                'content' => '点数不足，竞猜失败',
                'time' => date('H:i:s')
            );
            $points_tips['type'] = 'error';
            echo json_encode(['status' => 0, 'info' => $points_tips['content']]);
            exit;
        }
        if ($jnd28_1_state == 0 && false) {
            $time_error_message = array(
                'uid' => $userid,
                'type' => 'say',
                'head_img_url' => $message_data['headimgurl'],
                'from_client_name' => $message_data['client_name'],
                'content' => $message_data['content'],
                'time' => date('H:i:s')
            );
            $time_error_message['type'] = 'say_error';

            $time_message = array(
                'uid' => $userid,
                'type' => 'admin',
                'head_img_url' => '/Public/main/img/kefu.jpg',
                'from_client_name' => 'GM管理员',
                'content' => '「' . $message_data['content'] . '」' . '非开盘时间，购买失败',
                'time' => date('H:i:s')
            );
            $time_message['type'] = 'error';
            echo json_encode(['status' => 0, 'info' => $time_message['content']]);
            exit;
        } else {
            $time = time();
            if ($time > strtotime("23:55:30") && false) {
                $content_msg = "已封盘";
                $new_message = array(
                    'uid' => $userid,
                    'type' => 'admin',
                    'head_img_url' => '/Public/main/img/kefu.jpg',
                    'from_client_name' => 'GM管理员1',
                    'content' => $content_msg,
                    'time' => date('H:i:s')
                );
                $new_message['type'] = 'error';
                echo json_encode(['status' => 0, 'info' => '已封盘']);
                exit;
            }
            foreach ($json_data as $message_data) {

                /*检测格式和金额*/
                $res = check_format_bj28($message_data['content'], C($type . 'qi_min_point'), C($type . 'qi_max_point'), C($type . '_xz_open'), C($type . '_xz_max'));
                //$res['type'] =1 ;
                //$res['error'] = 1;
                if (false) {

                } else if ($res['type'] || true) {
                    /*查询积分*/
                    $jifen = M('user')->where("id = $userid")->find();
                    if ($jifen['points'] < $res['points']) {
                        $points_error = array(
                            'uid' => $userid,
                            'type' => 'say',
                            'head_img_url' => $message_data['headimgurl'],
                            'from_client_name' => $message_data['client_name'],
                            'content' => $message_data['content'],
                            'time' => date('H:i:s')
                        );
                        $points_error['type'] = 'say_error';
                        $points_tips = array(
                            'uid' => $userid,
                            'type' => 'admin',
                            'head_img_url' => '/Public/main/img/kefu.jpg',
                            'from_client_name' => 'GM管理员111',
                            'content' => '「' . $message_data['content'] . '」' . '点数不足，竞猜失败',
                            'time' => date('H:i:s')
                        );
                        $points_tips['type'] = 'error';
                        echo json_encode(['status' => 0, 'info' => $points_tips['content']]);
                        exit;
                    } else {
                        $jnd28_1data = F($type . 'data');
                        $user = M('user')->where("id = $userid")->find();
                        //当前玩法是否超过设置金额
                        $wf_points = M('order')->field("sum(del_points) as sum_del")->where("userid = {$userid} and type={$res['type']} and state=1  and number = {$jnd28_1data['next']['periodNumber']}")->find();
                        $wf_max_points = 0;
                        switch ($res['type']) {
                        case '1':
                            $wf_max_points = C($type . '_xz_max')['dxds'];
                            break;

                        case '2':
                            $wf_max_points = C($type . '_xz_max')['zuhe'];
                            break;

                        case '3':
                            $wf_max_points = C($type . '_xz_max')['jdx'];
                            break;

                        case '4':
                            $wf_max_points = C($type . '_xz_max')['zx'];
                            break;

                        case '5':
                            $wf_max_points = C($type . '_xz_max')['bds'];
                            break;

                        case '6':
                            $wf_max_points = C($type . '_xz_max')['tema'];
                            break;

                        default:
                            $wf_max_points = 0;
                            break;
                        }

                        if ($res['points'] > $wf_max_points && false) {
                            $points_tips = array(
                                'uid' => $userid,
                                'type' => 'admin',
                                'head_img_url' => '/Public/main/img/kefu.jpg',
                                'from_client_name' => 'GM管理员1111',
                                'content' => '「' . $message_data['content'] . '」' . '当前玩法每期最高数量' . $wf_max_points . ',您已超过，购买失败',
                                'time' => date('H:i:s')
                            );
                            $points_tips['type'] = 'error';
                            echo json_encode(['status' => 0, 'info' => $points_tips['content']]);
                            exit;
                        }

                        //查看已投注金额
                        $user_points = M('order')->field("sum(del_points) as sum_del")->where("userid = {$userid} and state=1  and number = {$jnd28_1data['next']['periodNumber']}")->find();

                        if ((intval($user_points['sum_del']) + $res['points']) > C($type . 'qi_max_point') && false) {
                            $points_tips = array(
                                'uid' => $userid,
                                'type' => 'admin',
                                'head_img_url' => '/Public/main/img/kefu.jpg',
                                'from_client_name' => 'GM管理员12',
                                'content' => '「' . $message_data['content'] . '」' . '每期最高点数' . C($type . 'qi_max_point') . ',您已超过，竞猜失败',
                                'time' => date('H:i:s')
                            );
                            $points_tips['type'] = 'error';
                            echo json_encode(['status' => 0, 'info' => $points_tips['content']]);
                            exit;
                        }
                        //判断时候低于进入房间最低点数
                        if ($user['points'] < C($type . '_usermin_point')) {
                            $points_tips = array(
                                'uid' => $userid,
                                'type' => 'admin',
                                'head_img_url' => '/Public/main/img/kefu.jpg',
                                'from_client_name' => 'GM管理员',
                                'content' => '您的点数低于加拿大28初级房进入最低点数' . C($type . '_usermin_point') . ',竞猜失败',
                                'time' => date('H:i:s')
                            );
                            $points_tips['type'] = 'error';
                            echo json_encode(['status' => 0, 'info' => $points_tips['content']]);
                            exit;
                        }
                        $map = [];
                        $map['userid'] = $userid;
                        $map['type'] = $res['type'];
                        $map['state'] = 1;
                        $map['is_add'] = 0;
                        $map['is_under'] = $user['is_under'];
                        $map['time'] = time();
                        $map['number'] = $jnd28_1data['next']['periodNumber'];
                        $map['jincai'] = $message_data['content'];
                        $map['del_points'] = $res['points'];
                        $map['balance'] = $user['points'] - $map['del_points'];
                        $map['nickname'] = $message_data['client_name'];
                        $map['username'] = $user['username'];
                        $map['game'] = F($type . '_game');
                        $map['is_robot'] = $user['is_robot'];
                        $map['t_id'] = $user['t_id'];
                        $map['jpgpath'] = ' ';
                        $return = M('order')->add($map);

                        if ($return) {
                            /*减分*/
                            $res_points = M('user')->where("id = $userid")->setDec('points', $map['del_points']);

                            if ($res_points) {
                                $points_del = array(
                                    'type' => 'points',
                                    'content' => $res['points'],
                                    'time' => date('H:i:s')
                                );
                            }
                            //生成记录图片
                            $jpg_str = $map['game'] . "  " . $map['number'] . "  " . date('Y-m-d H:i:s', $map['time']) . "  " . $map['nickname'] . "  " . $map['username'] . "  " . $map['jincai'] . "  " . $map['del_points'];

                            $jpgpath = create_jincaijpg($jpg_str);
                            header('Content-type: application/json');
                            $res_jpg = M('order')->where("id={$return}")->save(array('jpgpath' => $jpgpath));
                            //记录用户日志
                            $userlog = array(
                                'username' => $user['username'],
                                'nickname' => $user['nickname'],
                                'type' => 1, //1 下注  2中奖 3上分  4下分  5登录系统
                                'addtime' => time(),
                                'content' => "用户[" . $user['nickname'] . "]下注[" . $map['game'] . "][" . $message_data['content'] . "],竞猜成功，消耗" . $res['points'] . "点，投后剩余" . ($user['points'] - $map['del_points']) . "点",
                            );
                            M('userlog')->add($userlog);

                            $new_message2 = array(
                                'uid' => $userid,
                                'type' => 'say',
                                'status' => $user['is_under'],
                                'head_img_url' => $message_data['headimgurl'],
                                'from_client_name' => $message_data['client_name'],
                                'content' => $message_data['content'],
                                'time' => date('H:i:s')
                            );
                            /*成功通知*/
                            $new_message1 = array(
                                'uid' => $userid,
                                'type' => 'admin',
                                'head_img_url' => '/Public/main/img/kefu.jpg',
                                'from_client_name' => 'GM管理员',
                                'content' => '「' . $message_data['content'] . '」' . ',购买成功',
                                'time' => date('H:i:s')
                            );

                        } else {

                        }
                    }
                } else {
                    if (substr($message_data['content'], 0, 1) == '@') {
                        $uid_info = explode('|', $message_data['content'])[0];
                        $uid = substr($uid_info, 1);
                        $user = M('user')->where("id={$uid}")->find();
                        if ($user) {
                            $new_message6 = array(
                                'uid' => $user['id'],
                                'type' => 'say',
                                'status' => 1,
                                'head_img_url' => $message_data['headimgurl'],
                                'from_client_name' => $message_data['client_name'],
                                'content' => $message_data['content'],
                                'time' => date('H:i:s')
                            );
                        }
                    }

                    if (C('is_say')) {
                        $new_message2 = array(
                            'uid' => $userid,
                            'type' => 'say',
                            'status' => 1,
                            'head_img_url' => $message_data['headimgurl'],
                            'from_client_name' => $message_data['client_name'],
                            'content' => $message_data['content'],
                            'time' => date('H:i:s')
                        );

                    } else {
                        $format_error_message = array(
                            'uid' => $userid,
                            'type' => 'say',
                            'head_img_url' => $message_data['headimgurl'],
                            'from_client_name' => $message_data['client_name'],
                            'content' => $message_data['content'],
                            'time' => date('H:i:s')
                        );
                        $format_error_message['type'] = 'say_error';

                        $new_message3 = array(
                            'uid' => $userid,
                            'type' => 'admin',
                            'head_img_url' => '/Public/main/img/kefu.jpg',
                            'from_client_name' => 'GM管理员',
                            'content' => '「' . $message_data['content'] . '」' . '格式不正确,竞猜失败',
                            'time' => date('H:i:s')
                        );
                        $new_message3['type'] = 'error';
                        echo json_encode(['status' => 0, 'info' => $new_message3['content']]);
                        exit;
                    }

                }
            }
            echo json_encode(['status' => 1, 'info' => '请求成功']);
            exit;
        }
    }

    private function getLottoInfo( $type_room ){
        $lotto = explode('_', $type_room)[0];
        $room = explode('_', $type_room)[1];

        if (C('is_open') == 0) {
            $this->redirect('error');
        }

        // 10期结果
        $list = M('number')->where("game='$lotto'")
            ->order("id DESC")
            ->limit(10)
            ->select();

        // 创建SDK实例
        // $script = &load_wechat('Script');
        // 获取JsApi使用签名，通常这里只需要传 $ur l参数
        // $url = 'http://' . $_SERVER['SERVER_NAME'] . '/Home/Run/index.html';
        // $options = $script->getJsSign($url, $timestamp, $noncestr, $appid);
        // 2022/05/16 - 去掉微信请求
        $options=NULL;

        // 判断赛车和飞艇的类型
        $kefu = M('config')->where("id = 1")->find();

        $is_weixin = is_weixin();

        $userinfo = session('user');

        $map['state'] = 1;
        $map['userid'] = $userinfo['id'];
        $order = M('order');
        $points_tj = $order->field("count(id) as count,sum(add_points) as sum_add,sum(del_points) as sum_del")
            ->where($map)
            ->find();
        $points_tj['ying'] = $points_tj['sum_add'] - $points_tj['sum_del'];
        $this->assign('points_tj', $points_tj);

        foreach ($list as $key => $value) {
            $current_number = $value;
            $number1 = explode(',', $current_number['awardnumbers']);

            $numberOne = $number1[0];
            $numberTwo = $number1[1];
            $numberThree = $number1[2];

            $tema_number = $numberOne + $numberTwo + $numberThree;
            $current_number['numberOne'] = $numberOne;
            $current_number['numberTwo'] = $numberTwo;
            $current_number['numberThree'] = $numberThree;

            if ($tema_number <= 13) {
                if ($tema_number % 2 == 0) {
                    $current_number['zuhe'] = '小双';
                } else {
                    $current_number['zuhe'] = '小单';
                }
            } else {
                if ($tema_number % 2 == 0) {
                    $current_number['zuhe'] = '大双';
                } else {
                    $current_number['zuhe'] = '大单';
                }
            }
            if ($numberOne > $numberTwo) {
                $current_number['zx'] = '庄';
            } elseif ($numberOne == $numberTwo) {
                $current_number['zx'] = '和';
            } else {
                $current_number['zx'] = '闲';
            }
            $current_number['q3'] = bj28_qzh(array(
                $numberOne,
                $numberTwo,
                $numberThree
            ));

            if ($tema_number == 0) {
                $current_number['jdx'] = '极小';
            } else
                if ($tema_number ==  27) {
                    $current_number['jdx'] = '极大';
                } else {
                    $current_number['jdx'] = '';
                }
            $kjlist[$key] = $current_number;
        }

        $this->assign('kjlist', $kjlist);

        // 聊天信息
        $msglist = M('message')->where("status=1 and game='$type_room'")
            ->order("id DESC")
            ->limit(50)
            ->select();
        if (I('userid')) {
            $number = M('number')->where("game='$lotto'")->limit(0, 1)->order("id desc")->find();
            $n_awardTime = strtotime($number["awardtime"]) + 195;
            $userid = I('userid');
            $jifen = M('user')->where("id = $userid")->find();
            $fenxia_process = M('fenxia')->field('sum(money) as m')->where(['uid'=>$userid, 'status'=>0])->find();
            $jifen['points'] = $jifen['points'] - $fenxia_process['m'];
            $jifen['points'] = $jifen['points']>0?$jifen['points']:0;
            $jifen['points'] = floor($jifen['points']*100)/100;

            $xz_tema = array();
            for( $i = 0; $i < 14; $i++){
                $xz_tema[$i]=C($type_room.'_tema_'.$i);
            } // End For
            $data = [
                'tema' => $xz_tema,
                'msglist' => $msglist,
                'is_weixin' => $is_weixin,
                'kefu' => $kefu,
                'list' => $list,
                'type' => '',
                'kjlist' => $kjlist,
                'options' => $options,
                "preDrawCode" => explode(',', $number['awardnumbers']),
                "drawIssue" => $number['periodnumber'] + 1,
                "drawTime" => date('Y-m-d H:i:s', $n_awardTime),
                "preDrawIssue" => $number['periodnumber'],
                "sumNum" => $number['tema'],
                "sumBigSmall" => $number['tema_dx'],
                $type_room.'_dxds' => C($type_room.'_dxds'),
                $type_room.'_jdx' => C($type_room.'_jdx'),
                $type_room.'_zuhe_1' => C($type_room.'_zuhe_1'),
                $type_room.'_zuhe_2' => C($type_room.'_zuhe_2'),
                'points' => $jifen['points'],
                "time" => strval($n_awardTime - C($lotto.'_stop_time') - time()),
            ];
            echo json_encode(['info' => '成功', 'url' => '', 'status' => 1, 'data' => $data]);
            exit;
        }
        $this->assign('msglist', $msglist);

        $this->assign('is_weixin', $is_weixin);
        $this->assign('kefu', $kefu);

        $this->assign('list', $list);
        $this->assign('type', $type);
        $this->assign('options', $options);
        if (C('index_page') == $room) {
            $this->display($type_room);
        } else {
            $this->display();
        }
}

	public function getConfig(){
        $type = I('type');
        $qi_min_point =  C($type . 'qi_min_point');
        $qi_max_point =  C($type . 'qi_max_point');
        $_xz_open = C($type . '_xz_open');
        $_xz_max = C($type . '_xz_max');
        echo json_encode(['status'=>1,'data'=>['qi_min_point'=>$qi_min_point,'qi_max_point'=>$qi_max_point,'xz_max'=>$_xz_max,'xz_open'=>$_xz_open]]);exit;
    }

}


?>

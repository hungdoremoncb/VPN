<?php

namespace Home\Controller;
use Think\Controller;

header('content-type:text/html;charset=utf-8');
class CaiController extends Controller{

	public function test(){
		$list[$i]['jincai'] = '大100';
		$current_number['tema'] = '24';
		$current_number['tema_ds'] = '单';
		$current_number['tema_dx'] = '大';
		$start4 = substr($list[$i]['jincai'], 0,3);
		$starts4 = substr($list[$i]['jincai'],3);
		$num4 = 0;
		$points4 = 0;

		if (C('ssc_zdxds_ishe') == '1') {
			if ($current_number['tema'] == '23') {
				if ($start4 == '和') {
					$points4 = $starts4*C('ssc_zdxds_he');
					$num4++;
				}
			}else{
				if ($start4 == '大' || $start4 == '小') {
					if ($start4 == $current_number['tema_dx']) {
						$num4++;
						$points4 = $starts4*C('ssc_zdxds');
					}
				} else {
					if ($start4 == $current_number['tema_ds']) {
						$num4++;
						$points4 = $starts4*C('ssc_zdxds');
					}
				}
			}
		} else {
			if ($start4 == '大' || $start4 == '小') {
				if ($start4 == $current_number['tema_dx']) {
					$num4++;
					$points4 = $starts4*C('ssc_zdxds');
				}
			} else {
				if ($start4 == $current_number['tema_ds']) {
					$num4++;
					$points4 = $starts4*C('ssc_zdxds');
				}
			}
		}
		var_dump($num4);
		var_dump($points4);exit;


		$list[$i]['jincai'] = '124/100';
		$number1 = array(1,2,3,3,5);
		$start10 = explode('/', $list[$i]['jincai']);

		$num10 = 0;
		$number_qc = array_unique($number1);
		$starts10 = str_split($start10[0]);
		for($s=0;$s<count($starts10);$s++){
			for($a=0;$a<count($number_qc);$a++){
				if ($starts10[$s] == $number_qc[$a]) {
					$num10++;
				}
			}
		}
		var_dump($num10);exit;


		$list[$i]['jincai'] = '12/113.1335/100/去重';
		$number1 = array(1,3,4,5,6);
		$start9 = explode('/', $list[$i]['jincai']);
		$num91 = 0;
		$num92 = 0;

		$zu = explode('.', $start9[1]);
		$zu1 = str_split($zu[0]);
		$zu2 = str_split($zu[1]);
		$ws = str_split($start9[0]);
		// var_dump($zu1);
		// var_dump($zu2);
		foreach ($zu1 as  $v9) {
			foreach ($zu2 as $n9) {
				if ($v9 != $n9) {
					if ($number1[$ws[0]-1] == $v9 && $number1[$ws[1]-1] == $n9) {
						// var_dump($number1[$ws[0]-1]);
						$num91++;
					}

					
				}
			}
		}
		var_dump($num91);exit;
		var_dump($num92);exit;

		if($num6>0){
			if ($start6[0] == '0' || $start6[0] == '27') {
				$points6 = $num6*$start6[1]*C('bj28_tema_0');
			} else if($start6[0] == '1' || $start6[0] == '26') {
				$points6 = $num6*$start6[1]*C('bj28_tema_1');
			} else if($start6[0] == '2' || $start6[0] == '25') {
				$points6 = $num6*$start6[1]*C('bj28_tema_2');
			} else if($start6[0] == '3' || $start6[0] == '24') {
				$points6 = $num6*$start6[1]*C('bj28_tema_3');
			} else if($start6[0] == '4' || $start6[0] == '23') {
				$points6 = $num6*$start6[1]*C('bj28_tema_4');
			} else if($start6[0] == '5' || $start6[0] == '22') {
				$points6 = $num6*$start6[1]*C('bj28_tema_5');
			} else if($start6[0] == '6' || $start6[0] == '21') {
				$points6 = $num6*$start6[1]*C('bj28_tema_6');
			} else if($start6[0] == '7' || $start6[0] == '20') {
				$points6 = $num6*$start6[1]*C('bj28_tema_7');
			} else if($start6[0] == '8' || $start6[0] == '19') {
				$points6 = $num6*$start6[1]*C('bj28_tema_8');
			} else if($start6[0] == '9' || $start6[0] == '18') {
				$points6 = $num6*$start6[1]*C('bj28_tema_9');
			} else if($start6[0] == '10' || $start6[0] == '17') {
				$points6 = $num6*$start6[1]*C('bj28_tema_10');
			} else if($start6[0] == '11' || $start6[0] == '16') {
				$points6 = $num6*$start6[1]*C('bj28_tema_11');
			} else if($start6[0] == '12' || $start6[0] == '15') {
				$points6 = $num6*$start6[1]*C('bj28_tema_12');
			} else if($start6[0] == '13' || $start6[0] == '14') {
				$points6 = $num6*$start6[1]*C('bj28_tema_13');
			}
			var_dump($points6);exit;
			$res6 = $this->add_points($id,$userid,$points6);
			if($res6){
				$this->send_msg('pointsadd',$points6,$userid);
			}
		}

		
		for($a=0;$a<count($info_str8);$a++){
			if($current_number['tema']==$info_str8[$a]){
				if(in_array($info_str8[$a], $tema1)){
					$points8 += intval($start8[1]*C('pk10_tema_sz_1'));
				}
				if(in_array($info_str8[$a], $tema2)){
					$points8 += intval($start8[1]*C('pk10_tema_sz_2'));
				}
				if(in_array($info_str8[$a], $tema3)){
					$points8 += intval($start8[1]*C('pk10_tema_sz_3'));
				}
				if(in_array($info_str8[$a], $tema4)){
					$points8 += intval($start8[1]*C('pk10_tema_sz_4'));
				}
				if(in_array($info_str8[$a], $tema5)){
					$points8 += intval($start8[1]*C('pk10_tema_sz_5'));
				}
				$num8++;
			}
		}
		
	}

	public function sc2(){
		$url = "http://www.bwlc.net/bulletin/trax.html";
		$cpk = http_get($url);
		preg_match_all('/<td>(.*?)<\/td>/',$cpk, $out); 
		if (isset($out[1]) && $out[1]) {
			$periodnumber = strval($out[1][0]);
			$awardnumbers = strval($out[1][1]);
			$awardtime = strval($out[1][2]) . ":30";
		}
		if ($periodnumber && $awardnumbers && $awardtime) {
			$data = array(
				'periodnumber' => $periodnumber,
				'awardnumbers' => $awardnumbers,
				'awardtime' => $awardtime,
				'game' => 'pk10',
				'addtime' => time()
			);

			$caijinum = M('caiji')->where("game = 'pk10'")->limit(0,1)->order("id desc")->find();
			if (strval($caijinum['periodnumber']) != $periodnumber && $periodnumber > $caijinum['periodnumber']) {
				M('caiji')->add($data);
			}
		}
	}


	public function cpkpk(){
		$url = "http://u7a.chengdashizheng.com/chatbet_v3/game/loginweb.php";
		// var_dump($url);
		$cpk = file_get_contents($url);
		var_dump($cpk);exit;
		$cr_data = json_decode($cpk);
		foreach ($cr_data as $key => $value) {
			$periodnumber = $key;
			$awardtime = $value->dateline;
			$awardnumbers = $value->number;
			break;
		}

		if ($periodnumber && $awardnumbers && $awardtime) {
			$data = array(
				'periodnumber' => $periodnumber,
				'awardnumbers' => $awardnumbers,
				'awardtime' => $awardtime,
				'game' => 'pk10',
				'addtime' => time()
			);

			$caijinum = M('caiji')->where("game = 'pk10'")->limit(0,1)->order("id desc")->find();
			if (strval($caijinum['periodnumber']) != $periodnumber  && $periodnumber > $caijinum['periodnumber']) {
				M('caiji')->add($data);
			}
		}		
	}
	
	public function ft1(){
		$url = "https://www.pk10tv.com/index.php?c=content&a=list&catid=138";
		$cpk = http_get($url);
		preg_match('/<tbody.*?id=\"reslist\">\s*<tr >\s*<td>(.*?)<\/td>\s*<td> (.*?) <\/td>/',$cpk, $num); 
		if (isset($num[1]) && $num[1]) {
			$awardtime = $num[1];
			$periodnumber = $num[2];
		}
		preg_match_all('/<span title="(.*?)" class="ball_pks_  ball_pks.*? ball_lenght10  ">\s*.*?<\/span>/',$cpk, $pnum); 
		$awardnumbers = array();
		if (isset($pnum[1]) && $pnum[1]) {
			$awardnumbers = array();
			foreach ($pnum[1] as $key => $value) {
				if ($key < 10) {
					continue;
				}
				if ($key >= 20) {
					break;
				}
				$awardnumbers[] = $value < 10 ? '0'.$value : $value;

			}
		}
		$awardnumbers = implode(',', $awardnumbers);
		if ($periodnumber && $awardnumbers && $awardtime) {
			$data = array(
				'periodnumber' => $periodnumber,
				'awardnumbers' => $awardnumbers,
				'awardtime' => $awardtime,
				'game' => 'xyft',
				'addtime' => time()
			);

			$caijinum = M('caiji')->where("game = 'xyft'")->limit(0,1)->order("id desc")->find();
			if (strval($caijinum['periodnumber']) != $periodnumber && $periodnumber > $caijinum['periodnumber']) {
				M('caiji')->add($data);
			}
		}
	}

	public function dd(){
				//pk10开奖采集,pk10tv
				$time = time();
				if ($time > strtotime("09:00::00") and $time < strtotime("23:59:59")) {
					$url = "http://www.pk10tv.com/index.php?c=content&a=list&catid=2";
					$cpk = file_get_contents($url);
					
					preg_match('/<tbody.*?id=\"reslist\">\s*<tr >\s*<td>(.*?)<\/td>\s*<td> (.*?) <\/td>/',$cpk, $num); 
					if (isset($num[1]) && $num[1]) {
						$awardtime = $num[1];
						$periodnumber = $num[2];
					}

					preg_match_all('/<span title="(.*?)" class="ball_pks_  ball_pks.*? ball_lenght10  ">\s*.*?<\/span>/',$cpk, $pnum); 

					$awardnumbers = array();
					if (isset($pnum[1]) && $pnum[1]) {
						$awardnumbers = array();
						foreach ($pnum[1] as $key => $value) {
							if ($key < 10) {
								continue;
							}
							if ($key >= 20) {
								break;
							}
							$awardnumbers[] = $value;

						}
					}
					$awardnumbers = implode(',', $awardnumbers);
					
					if ($periodnumber && $awardnumbers && $awardtime) {
						$data = array(
							'periodnumber' => $periodnumber,
							'awardnumbers' => $awardnumbers,
							'awardtime' => $awardtime,
							'game' => 'pk10',
							'addtime' => time()
						);

						$caijinum = M('caiji')->where("game = 'pk10'")->limit(0,1)->order("id desc")->find();
						if (strval($caijinum['periodnumber']) != $periodnumber  && $periodnumber > $caijinum['periodnumber']) {
							M('caiji')->add($data);
						}
					}			
				} 
	}

	public function sc1(){
		
		$url = "http://www.pk10tv.com/index.php?c=content&a=list&catid=2";
		$cpk = file_get_contents($url);
		
		preg_match('/<tbody.*?id=\"reslist\">\s*<tr >\s*<td>(.*?)<\/td>\s*<td> (.*?) <\/td>/',$cpk, $num); 
		if (isset($num[1]) && $num[1]) {
			$awardtime = $num[1];
			$periodnumber = $num[2];
		}

		preg_match_all('/<span title="(.*?)" class="ball_pks_  ball_pks.*? ball_lenght10  ">\s*.*?<\/span>/',$cpk, $pnum); 

		$awardnumbers = array();
		if (isset($pnum[1]) && $pnum[1]) {
			$awardnumbers = array();
			foreach ($pnum[1] as $key => $value) {
				if ($key < 10) {
					continue;
				}
				if ($key >= 20) {
					break;
				}
				$awardnumbers[] = $value;

			}
		}
		$awardnumbers = implode(',', $awardnumbers);
		if ($periodnumber && $awardnumbers && $awardtime) {
			$data = array(
				'periodnumber' => $periodnumber,
				'awardnumbers' => $awardnumbers,
				'awardtime' => $awardtime,
				'game' => 'pk10',
				'addtime' => time()
			);

			$caijinum = M('caiji')->where("game = 'pk10'")->limit(0,1)->order("id desc")->find();
			if (strval($caijinum['periodnumber']) != $periodnumber  && $periodnumber > $caijinum['periodnumber']) {
				M('caiji')->add($data);
			}
		}
	}
}

?>
<?php

namespace Home\Controller;
use Think\Controller;
header('content-type:text/html;charset=utf-8');
class BaseController extends Controller{

    public function display($templateFile = '', $charset = '', $contentType = '', $content = '', $prefix = ''){
        $this->redirect('/');
    }

	public function _initialize(){

		// if ($_GET['auth_code'] != C('auth_code')) {
		// 	if (session('s_authcode') != C('auth_code')) {
		// 		exit('禁止访问，请联系管理员或客服，错误码ERR-'.GetRandStr(50));exit;
		// 	}
		// } else{
		// 	session('s_authcode',$_GET['auth_code']);
		// }
		if (true){

			$userid = I('userid')? I('userid') :I('post.uid');
            if ($userid ){
                session('userid',$userid);
                $info=M('user')->where('id='.$userid)->find();
                session('user',$info);
            }
        }
		//检测登录状态
		$userid = session('user');
		if (C('is_weixin') == '1' && is_weixin()) {
			if(CONTROLLER_NAME!='Index'){
				if(empty($userid['id'])){
					$this->redirect('Index/index');
				}
			}
		} else {
			if(CONTROLLER_NAME!='Index' && CONTROLLER_NAME!='Run' && ACTION_NAME !='zs' ){
				if(empty($userid['id'])){
                    $this->redirect('Index/login');
				}
			} else if (CONTROLLER_NAME =='Index' && ACTION_NAME !='wanfa'&& ACTION_NAME !='act_list'){
				if(empty($userid['id'])){
					if (ACTION_NAME =='register'){
                        //$this->redirect('Index/register');
					}else if (ACTION_NAME !='index' && ACTION_NAME !='login' && ACTION_NAME !='getSysTime' ){
						$this->redirect('Index/login');
					}
				}
			}
		}

		if (isset($userid['id'])) {
			$userinfo = M('user')->where("id = {$userid['id']}")->find();
		} else {
			$userinfo = array();
		}
		$this->assign('userinfo',$userinfo);
	}
}
?>
